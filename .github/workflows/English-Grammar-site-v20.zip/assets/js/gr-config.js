window.GR_CFG = {"url": "https://physicswijaz-commits.github.io/E-g/", "wa": "923409368103", "version": "v20"};
