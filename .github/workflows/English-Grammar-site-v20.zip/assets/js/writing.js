/* Writing templates page: copy buttons. */
document.addEventListener('click', function (e) {
  var b = e.target.closest && e.target.closest('.wr-copy'); if (!b) return;
  var el = document.getElementById(b.getAttribute('data-t')); if (!el) return;
  var txt = el.textContent, done = function () { b.textContent = 'Copied ✓'; setTimeout(function () { b.textContent = 'Copy'; }, 1500); };
  if (navigator.clipboard && navigator.clipboard.writeText) navigator.clipboard.writeText(txt).then(done, fb); else fb();
  function fb() { var r = document.createRange(); r.selectNodeContents(el); var s = getSelection(); s.removeAllRanges(); s.addRange(r); try { document.execCommand('copy'); done(); } catch (x) {} }
});
