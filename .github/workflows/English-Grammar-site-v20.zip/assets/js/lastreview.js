/* Last review page: tick topics as revised (saved on this phone). */
(function () {
  var KEY = 'lastReview', done = {};
  try { done = JSON.parse(localStorage.getItem(KEY) || '{}') || {}; } catch (e) {}
  function save() { try { localStorage.setItem(KEY, JSON.stringify(done)); } catch (e) {} }
  function paint() {
    var n = 0;
    document.querySelectorAll('.lr-card').forEach(function (c) {
      var k = c.getAttribute('data-n'), on = !!done[k]; if (on) n++;
      c.classList.toggle('done', on);
      var b = c.querySelector('.lr-done'); b.setAttribute('aria-pressed', on ? 'true' : 'false'); b.textContent = on ? 'Revised ✓ (tap to undo)' : 'Mark as revised';
    });
    document.getElementById('lr-done').textContent = n;
    document.getElementById('lr-fill').style.width = Math.round(n / 18 * 100) + '%';
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest && e.target.closest('.lr-done');
    if (b) { var k = b.getAttribute('data-n'); if (done[k]) delete done[k]; else done[k] = 1; save(); paint(); return; }
    if (e.target.id === 'lr-reset') { if (confirm('Clear all ticks?')) { done = {}; save(); paint(); } }
    if (e.target.id === 'lr-open') document.querySelectorAll('.lr-card').forEach(function (c) { c.open = true; });
    if (e.target.id === 'lr-close') document.querySelectorAll('.lr-card').forEach(function (c) { c.open = false; });
  });
  paint();
})();
